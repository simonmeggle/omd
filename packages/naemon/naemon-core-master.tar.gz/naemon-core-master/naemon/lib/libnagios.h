#ifndef LIBNAEMON_libnagios_h__
#define LIBNAEMON_libnagios_h__
/**
 * @file libnagios.h
 *
 * @brief Compat header to facilitate using Nagios projects with Naemon
 */
#include "libnaemon.h"
#endif /* LIBNAEMON_libnagios_h__ */
