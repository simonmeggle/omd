#!/usr/bin/perl
# nagios: +epn

print "sample output but no exit\n";
