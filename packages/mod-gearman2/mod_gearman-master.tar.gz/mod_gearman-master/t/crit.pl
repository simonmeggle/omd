#!/usr/bin/perl

print "test plugin CRITICAL\n";
print STDERR "some errors on stderr\n";
exit 2;
